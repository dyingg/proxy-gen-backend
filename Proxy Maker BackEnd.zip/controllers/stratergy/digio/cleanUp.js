const request = require("request");

function deleteScript(key, id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}
module.exports = deleteScript;
