const request = require("request");

function createScript(key, auth) {
  return new Promise(function(resolve, reject) {
    resolve({});
  });
}

module.exports = createScript;
